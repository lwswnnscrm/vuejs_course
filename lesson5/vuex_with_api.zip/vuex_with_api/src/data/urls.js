const urls = {
  hostApi: `https://api.charidy.com`,
  getCampaign: `/api/v1/campaign/:id`,
};

export default urls;
